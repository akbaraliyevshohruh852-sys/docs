import asyncio
import logging
import sys
import os
from flask import Flask, request
from aiogram.types import Update
from bot.main import bot, dp, setup_dispatcher
from core.database import init_db

# Logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Setup Dispatcher (Routers/Middleware)
setup_dispatcher()

def run_async(coro):
    """
    Sync contextdan async funksiyani chaqirish uchun yordamchi.
    Har bir zapros uchun yangi event loop yaratadi.
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()

# Dastur ishga tushganda DB ni sozlash
try:
    run_async(init_db())
    logger.info("Database initialized successfully via Flask")
except Exception as e:
    logger.error(f"Database Init Failed: {e}")


@app.route('/')
def home():
    return "<h1>Jonli Taxi Bot - Webhook Server</h1><p>Bot ishlayapti.</p>"


@app.route(f'/webhook/{bot.token}', methods=['POST'])
def webhook_handler():
    """
    Telegramdan kelgan yangilanishlarni qabul qilish
    """
    if request.method == 'POST':
        try:
            update_data = request.json
            update = Update.model_validate(update_data)
            
            # Update ni botga yuborish
            run_async(dp.feed_update(bot, update))
            
            return "ok"
        except Exception as e:
            logger.error(f"Webhook error: {e}")
            return "error", 500
    return "forbidden", 403


# PythonAnywhere da WSGI fayl uchun "app" obyektini eksport qilish kerak
# Bu fayl o'zi app obyektini taqdim etadi.
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
