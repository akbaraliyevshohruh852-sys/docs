# core/config.py
import os

# Telegram Bot Token
TOKEN = "8135159824:AAHfVvSrjKQ5ita9hFzyqlQWDw1ihq_WHzM"

# Adminlar ID ro'yxati
ADMIN_IDS = [5200168486, 7937744235]

# Guruhlar IDlari
DRIVER_GROUP_ID = -1003344171936   # Asosiy haydovchilar guruhi
VIP_GROUP_ID = -1003344171936      # VIP guruh

# Majburiy obuna bo'lish kerak bo'lgan kanallar (ro'yxat shaklida)
MANDATORY_CHANNELS = [
    {
        "chat_id": -1003623161520,
        "url": "https://t.me/jonlitaxivodiy",
        "name": "Jonli Taxi Vodiy"
    },
    # Qo'shimcha kanal qo'shmoqchi bo'lsangiz shu yerga qo'shing:
    # {
    #     "chat_id": -100XXXXXXXXXX,
    #     "url": "https://t.me/kanal_nomi",
    #     "name": "Ikkinchi kanal"
    # }
]

# Admin bilan bog'lanish
ADMIN_CONTACT = "7937744235"

# Ommaviy guruh (Yo'lovchilar uchun) – eski usul, agar hali ishlatilsa
PUBLIC_GROUP_URL = "https://t.me/jonlitaxivodiy"
PUBLIC_GROUP_CHAT_ID = -1003623161520  # Obunani tekshirish uchun

# Grabber (Xabar yig'uvchi) uchun manba guruhlar IDlari
GRABBER_SOURCES = [
    -1003623161520,   # Jonli Taxi Vodiy
    -1003560973274    # Yangi guruh
]

# To'lov ma'lumotlari
PAYMENT_CARD = "9860 3501 4062 9212"
PAYMENT_CARD_OWNER = "Usmonov Samandar"
PAYMENT_AMOUNT = "20000"  # Raqam sifatida, vergul emas

# Ma'lumotlar bazasi nomi
# Ma'lumotlar bazasi URL (Render/Postgres uchun)
# Ma'lumotlar bazasi URL (Render/Postgres uchun)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
default_db_path = os.path.join(BASE_DIR, "vodiy_express.db")

DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{default_db_path}")
DB_PATH = default_db_path # Fallback for local sqlite

# Eskiz SMS API (environment variables dan o'qiladi)
ESKIZ_EMAIL = os.getenv("ESKIZ_EMAIL", "")
ESKIZ_PASSWORD = os.getenv("ESKIZ_PASSWORD", "")
ESKIZ_TOKEN = os.getenv("ESKIZ_TOKEN", "")
