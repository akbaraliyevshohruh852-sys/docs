from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from core.config import ADMIN_CONTACT


def _normalize_telegram_url(url: str) -> str:
    """Telegram username yoki URL ni to'g'ri HTTPS formatga keltiradi."""
    url = url.strip()
    if not url:
        return "https://t.me/"
    if url.startswith("https://"):
        return url
    if url.startswith("http://"):
        return "https://" + url[7:]
    if url.startswith("t.me/"):
        return "https://" + url
    if url.startswith("@"):
        return f"https://t.me/{url[1:]}"  # ✅ Bo'shliqsiz!
    return f"https://t.me/{url}"  # ✅ Bo'shliqsiz!


def _build_admin_contact_url(contact: str) -> str:
    """
    Admin aloqa uchun to'g'ri URL yasaydi.
    Agar contact faqat raqamlardan iborat bo'lsa → tg://user?id=...
    Aks holda → https://t.me/... formatiga o'tkaziladi.
    """
    contact = contact.strip()
    if not contact:
        return "https://t.me/"
    if contact.isdigit():
        return f"tg://user?id={contact}"
    return _normalize_telegram_url(contact)


# === FOYDALANUVCHI KLAVIATURALARI ===

def role_kb():
    contact_url = _build_admin_contact_url(str(ADMIN_CONTACT))
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🙋‍♂️ Yo'lovchiman", callback_data="role_passenger"),
            InlineKeyboardButton(text="🚕 Haydovchiman", callback_data="role_driver")
        ],
        [InlineKeyboardButton(text="👤 Shaxsiy kabinet", callback_data="role_profile")],
        [
            InlineKeyboardButton(text="ℹ️ Bot haqida", callback_data="bot_info"),
            InlineKeyboardButton(text="📜 Shartnoma (Qoidalar)", callback_data="bot_terms")
        ],
        [InlineKeyboardButton(text="💬 Admin bilan bog'lanish", url=contact_url)]
    ])


def passenger_main_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🚖 Jo'nab ketish", callback_data="p_taxi")],
        [InlineKeyboardButton(text="📦 Jo'natma yuborish", callback_data="p_delivery")],
        [InlineKeyboardButton(text="👥 VIP Xizmatlar", callback_data="p_vip")],
        [
            InlineKeyboardButton(text="👤 Shaxsiy kabinet", callback_data="role_profile"),
            InlineKeyboardButton(text="◀️ Ortga", callback_data="back_to_role")
        ]
    ])


def driver_main_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👤 Profilim", callback_data="d_profile")],
        [InlineKeyboardButton(text="💰 Balansni to'ldirish", callback_data="d_refill")],
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data="back_to_role")]
    ])

def locations_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Andijon", callback_data="loc_Andijon"),
            InlineKeyboardButton(text="Namangan", callback_data="loc_Namangan"),
            InlineKeyboardButton(text="Farg‘ona", callback_data="loc_Farg‘ona")
        ],
        [InlineKeyboardButton(text="Toshkent", callback_data="loc_Toshkent")],
        [InlineKeyboardButton(text="Qo‘shimcha manzil yozish...", callback_data="loc_custom")],
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data="back_to_role")]
    ])


def destinations_kb(from_loc):
    if from_loc in ["Andijon", "Namangan", "Farg‘ona"]:
        kb = [
            [
                InlineKeyboardButton(text="Toshkent", callback_data="dest_Toshkent"),
                InlineKeyboardButton(text="Chirchiq", callback_data="dest_Chirchiq"),
                InlineKeyboardButton(text="Angren", callback_data="dest_Angren")
            ],
            [InlineKeyboardButton(text="Boshqa...", callback_data="dest_custom")],
            [
                InlineKeyboardButton(text="⬅️ Ortga", callback_data="back_to_from"),
                InlineKeyboardButton(text="❌ Bekor qilish", callback_data="back_to_role")
            ]
        ]
    else:
        kb = [
            [
                InlineKeyboardButton(text="Andijon", callback_data="dest_Andijon"),
                InlineKeyboardButton(text="Namangan", callback_data="dest_Namangan"),
                InlineKeyboardButton(text="Farg‘ona", callback_data="dest_Farg‘ona")
            ],
            [InlineKeyboardButton(text="Boshqa...", callback_data="dest_custom")],
            [
                InlineKeyboardButton(text="⬅️ Ortga", callback_data="back_to_from"),
                InlineKeyboardButton(text="❌ Bekor qilish", callback_data="back_to_role")
            ]
        ]
    return InlineKeyboardMarkup(inline_keyboard=kb)


def time_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📅 Bugun", callback_data="time_today"),
            InlineKeyboardButton(text="📅 Ertaga", callback_data="time_tomorrow")
        ],
        [InlineKeyboardButton(text="🕒 Aniq vaqt kiriting...", callback_data="time_custom")],
        [
            InlineKeyboardButton(text="⬅️ Ortga", callback_data="back_to_dest"),
            InlineKeyboardButton(text="❌ Bekor qilish", callback_data="back_to_role")
        ]
    ])


def skip_kb(callback_data):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎤 Ovozli xabar yozish 🎧", callback_data="order_voice")],
        [InlineKeyboardButton(text="⏩ O'tkazib yuborish", callback_data="skip_details")],
        [
            InlineKeyboardButton(text="⬅️ Ortga", callback_data=callback_data),
            InlineKeyboardButton(text="❌ Bekor qilish", callback_data="back_to_role")
        ]
    ])


def car_types_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Damas", callback_data="car_Damas"),
            InlineKeyboardButton(text="Gentra", callback_data="car_Gentra"),
            InlineKeyboardButton(text="Cobalt", callback_data="car_Cobalt")
        ],
        [
            InlineKeyboardButton(text="Nexia", callback_data="car_Nexia"),
            InlineKeyboardButton(text="Boshqa...", callback_data="car_custom")
        ]
    ])


def license_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Ha ✅", callback_data="license_yes"),
            InlineKeyboardButton(text="Yo‘q ❌", callback_data="license_no")
        ]
    ])


def confirm_order_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Buyurtmani yuborish", callback_data="confirm_order")],
        [InlineKeyboardButton(text="↩️ Barchasini qayta to‘ldirish", callback_data="back_to_role")]
    ])


def back_kb(callback_data):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data=callback_data)]
    ])


def skip_location_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⏩ O'tkazib yuborish", callback_data="skip_location")],
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data="back_to_dest")]
    ])


def accept_order_kb(order_id, user_id, phone):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👤 Profil", url=f"tg://user?id={user_id}")],
        [InlineKeyboardButton(text="✅ Buyurtmani qabul qilish", callback_data=f"accept_{order_id}")]
    ])


def check_sub_kb(channel_url):
    url = _normalize_telegram_url(channel_url)
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📢 Guruhga qo'shiling", url=url)],
        [InlineKeyboardButton(text="✅ Tekshirish", callback_data="check_subscription")]
    ])


# === ADMIN PANEL KLAVIATURALARI ===

def admin_panel_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📊 Dashboard", callback_data="admin_stats"),
            InlineKeyboardButton(text="🚗 Haydovchilar", callback_data="admin_drivers")
        ],
        [
            InlineKeyboardButton(text="📦 Buyurtmalar (30 ta)", callback_data="admin_orders"),
            InlineKeyboardButton(text="👥 Foydalanuvchilar (Boshqaruv)", callback_data="admin_users_menu")
        ],
        [
            InlineKeyboardButton(text="💰 To'lovlar (Cheklar)", callback_data="admin_payments"),
            InlineKeyboardButton(text="📢 Reklama (Broadcast)", callback_data="admin_broadcast")
        ],
        [
            InlineKeyboardButton(text="👥 Guruhlar boshqaruvi", callback_data="admin_groups"),
            InlineKeyboardButton(text="🛡 Adminlarni boshqarish", callback_data="admin_manage_admins")
        ],
        [
            InlineKeyboardButton(text="⚙️ Sozlamalar", callback_data="admin_settings"),
            InlineKeyboardButton(text="🦅 Grabber Sozlamalari", callback_data="admin_grabber")
        ],
        [InlineKeyboardButton(text="🚫 Qora ro'yxat", callback_data="admin_blacklist")],
        [InlineKeyboardButton(text="📁 Bazani yuklab olish", callback_data="admin_download_db")]
    ])




def admin_users_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🚗 Haydovchilar", callback_data="show_all_drivers"),
            InlineKeyboardButton(text="🚶 Yo'lovchilar", callback_data="show_all_passengers")
        ],
        [
            InlineKeyboardButton(text="💎 VIP Haydovchilar", callback_data="show_vip_drivers"),
            InlineKeyboardButton(text="🌐 Barcha foydalanuvchilar", callback_data="show_all_users_combined")
        ],
        [InlineKeyboardButton(text="🔎 Foydalanuvchi qidirish", callback_data="admin_search_user")],
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data="admin_main_menu")]
    ])


def admin_driver_manage_kb(tid):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💰 Balansni to'ldirish", callback_data=f"refill_one_{tid}")],
        [InlineKeyboardButton(text="✉️ Xabar yozish", callback_data=f"message_user_{tid}")],
        [InlineKeyboardButton(text="👤 Profilga o'tish", url=f"tg://user?id={tid}")],
        [InlineKeyboardButton(text="🚫 Bloklash", callback_data=f"block_user_{tid}")],
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data="admin_drivers")]
    ])


def admin_order_manage_kb(oid):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Buyurtmani o'chirish", callback_data=f"delete_order_{oid}")],
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data="admin_orders")]
    ])


def admin_payment_kb(pid, uid):
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"pay_approve_{pid}_{uid}"),
            InlineKeyboardButton(text="❌ Rad etish", callback_data=f"pay_reject_{pid}_{uid}")
        ],
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data="admin_payments")]
    ])


def admin_back_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Admin Menyu", callback_data="admin_main_menu")]
    ])


def back_to_main_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏠 Asosiy menyu", callback_data="back_to_role")]
    ])
