from aiogram import Router, types, F, Bot
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
import asyncio
import logging
from datetime import datetime

from core import database as db
from core.config import (
    DRIVER_GROUP_ID, VIP_GROUP_ID, ADMIN_IDS, GRABBER_SOURCES, DB_PATH
)
from bot.keyboards.inline import (
    admin_panel_kb, admin_back_kb, admin_driver_manage_kb,
    admin_order_manage_kb, admin_payment_kb
)
from bot.states.states import AdminState
from bot.utils.filters import IsAdmin

logger = logging.getLogger(__name__)
router = Router()


# ==========================================
# 1. ASOSIY ADMIN PANEL
# ==========================================
@router.message(Command("admin"), IsAdmin())
async def admin_main(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "👨‍💼 <b>SHOHRUHBEK BOSHQARUV PANELI</b>\n"
        "━━━━━━━━━━━━━━━\n\n"
        "Xush kelibsiz! Botni boshqarish uchun quyidagi bo'limlardan birini tanlang:",
        reply_markup=admin_panel_kb(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "admin_main_menu", IsAdmin())
async def admin_main_cb(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        "👨‍💼 <b>SHOHRUHBEK BOSHQARUV PANELI</b>\n"
        "━━━━━━━━━━━━━━━\n\n"
        "Xush kelibsiz! Botni boshqarish uchun quyidagi bo'limlardan birini tanlang:",
        reply_markup=admin_panel_kb(),
        parse_mode="HTML"
    )
    await callback.answer()


# ==========================================
# 2. STATISTIKA (DASHBOARD)
# ==========================================
@router.callback_query(F.data == "admin_stats", IsAdmin())
async def admin_stats_callback(callback: types.CallbackQuery):
    stats = await db.get_stats()
    blacklist_count = len(await db.get_blacklist())

    text = (
        "📊 **BOT STATISTIKASI (UMUMIY)**\n"
        "━━━━━━━━━━━━━━━\n\n"
        f"🗓 **Bugungi buyurtmalar:** `{stats.get('today_orders', 0)}` ta\n"
        f"📦 **Jami buyurtmalar:** `{stats.get('total_orders', 0)}` ta\n\n"
        f"👥 **Jami yo'lovchilar:** `{stats.get('total_passengers', 0)}` ta\n"
        f"🚗 **Jami haydovchilar:** `{stats.get('total_drivers', 0)}` ta\n"
        f"✅ **Faol haydovchilar:** `{stats.get('active_drivers', 0)}` ta\n"
        f"🚫 **Qora ro'yxatdagilar:** `{blacklist_count}` ta\n\n"
        "━━━━━━━━━━━━━━━"
    )

    await callback.message.edit_text(
        text,
        reply_markup=admin_back_kb(),
        parse_mode="HTML"
    )
    await callback.answer()


# ==========================================
# 3. HAYDOVCHILARNI BOSHQARISH
# ==========================================
@router.callback_query(F.data == "admin_drivers", IsAdmin())
async def admin_drivers_callback(callback: types.CallbackQuery):
    drivers = await db.get_all_drivers(limit=10)
    if not drivers:
        await callback.message.edit_text(
            "📭 **Haydovchilar bazada mavjud emas.**",
            reply_markup=admin_back_kb(),
            parse_mode="HTML"
        )
        return

    await callback.message.edit_text("🚗 **OXIRGI 10 TA HAYDOVCHI:**", reply_markup=None)

    for d in drivers:
        status_emoji = "🟢" if d['status'] == 'active' else "⏳" if d['status'] == 'pending' else "🔴"
        text = (
            f"{status_emoji} **{d['full_name']}**\n"
            f"🆔 ID: `{d['telegram_id']}`\n"
            f"📞 Tel: `+{d['phone']}`\n"
            f"🚗 Mashina: **{d['car_type']}**\n"
            f"💰 Balans: `{d.get('balance', 0):,} so'm`\n"
            f"⚙️ Status: **{d['status'].upper()}**"
        )
        kb = admin_driver_manage_kb(d['telegram_id'])
        await callback.message.answer(text, reply_markup=kb, parse_mode="Markdown")

    await callback.message.answer(
        "☝️ Yuqoridagi haydovchilarni boshqarishingiz mumkin.",
        reply_markup=admin_back_kb(),
        parse_mode="HTML"
    )
    await callback.answer()


# ==========================================
# 4. BUYURTMALARNI BOSHQARISH (OXIRGI 30 TA)
# ==========================================
@router.callback_query(F.data == "admin_orders", IsAdmin())
async def admin_orders_callback(callback: types.CallbackQuery):
    orders = await db.get_recent_orders(limit=30)
    if not orders:
        await callback.message.edit_text(
            "📭 **Hozircha buyurtmalar yo'q.**",
            reply_markup=admin_back_kb(),
            parse_mode="HTML"
        )
        return

    await callback.message.edit_text("📦 **OXIRGI 30 TA BUYURTMA:**", reply_markup=None)

    for o in orders:
        txt = (
            f"📦 **Order #{o['id']}** | {o['type']}\n"
            f"📍 {o['from_loc']} ➡️ {o['to_loc']}\n"
            f"👤 Mijoz: {o.get('passenger_name', 'Noma\'lum')} (`{o['user_id']}`)\n"
            f"📅 Vaqt: {o['time_val']}\n"
            f"⚙️ Status: **{o['status'].upper()}**"
        )
        kb = admin_order_manage_kb(o['id'])
        await callback.message.answer(txt, reply_markup=kb, parse_mode="Markdown")

    await callback.message.answer(
        "☝️ Keraksiz buyurtmalarni o'chirishingiz mumkin.",
        reply_markup=admin_back_kb(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("delete_order_"), IsAdmin())
async def delete_order_callback(callback: types.CallbackQuery):
    oid = int(callback.data.split("_")[2])
    await db.delete_order(oid)
    await callback.message.edit_text(f"🗑 **Buyurtma #{oid} o'chirildi!**")
    await callback.answer("Buyurtma o'chirildi")


# ==========================================
# 5. TO'LOVLARNI TASDIQLASH / RAD ETISH (DOIMIY SAQLANADI)
# ==========================================
@router.callback_query(F.data == "admin_payments", IsAdmin())
async def admin_payments_callback(callback: types.CallbackQuery):
    pays = await db.get_pending_payments()  # faqat pending holatdagi to'lovlar
    if not pays:
        await callback.message.edit_text(
            "💰 **Tasdiqlanmagan to'lovlar yo'q.**",
            reply_markup=admin_back_kb(),
            parse_mode="HTML"
        )
        return

    await callback.message.edit_text(
        f"💰 **TASDIQLANMAGAN TO'LOVLAR:** ({len(pays)} ta)",
        reply_markup=None
    )

    for p in pays:
        txt = (
            f"💳 **TO'LOV #{p['id']}**\n"
            f"👤 Haydovchi: {p['full_name']} (`{p['user_id']}`)\n"
            f"💰 Summa: `{p['amount']:,}` so'm\n"
            f"📅 Vaqt: {p['created_at']}"
        )
        kb = admin_payment_kb(p['id'], p['user_id'])
        await callback.message.answer_photo(p['photo_id'], caption=txt, reply_markup=kb)

    await callback.message.answer(
        "☝️ To'lovlarni tasdiqlang yoki rad eting.\n\n"
        "<b>Eslatma:</b> Tasdiqlangan/rad etilgan to'lovlar bazada saqlanib qoladi.",
        reply_markup=admin_back_kb(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("pay_approve_"), IsAdmin())
async def pay_approve(callback: types.CallbackQuery):
    _, _, pid_str, uid_str = callback.data.split("_")
    pid = int(pid_str)
    uid = int(uid_str)

    await db.update_payment_status(pid, 'approved')

    pay = await db._execute("SELECT amount FROM payments WHERE id = ?", (pid,), fetch_one=True)
    if pay:
        await db.update_driver_balance(uid, pay['amount'], mode='add')
        from datetime import datetime, timedelta
        sub_end = datetime.now() + timedelta(days=30)
        await db.update_driver_subscription(uid, sub_end)

    # VIP guruh linklari
    vip_ids_str = await db.get_setting('vip_group_ids', str(VIP_GROUP_ID))
    vip_ids = [int(i.strip()) for i in vip_ids_str.split(",") if i.strip()]

    links = []
    for g_id in vip_ids:
        try:
            invite = await callback.bot.create_chat_invite_link(g_id, member_limit=1)
            links.append(invite.invite_link)
        except Exception as e:
            logger.error(f"Invite link xatosi {g_id}: {e}")

    # Tugmalarni yasash
    buttons = []
    if links:
        for idx, link in enumerate(links, 1):
            buttons.append([InlineKeyboardButton(text=f"� VIP Guruhga qo'shilish #{idx}", url=link)])
    
    # Asosiy menyuga qaytish tugmasini ham qo'shamiz
    buttons.append([InlineKeyboardButton(text="🏠 Asosiy menyu", callback_data="back_to_role")])

    welcome = (
        "✅ **TO'LOVINGIZ TASDIQLANDI!**\n\n"
        "Balansingiz to'ldirildi va obuna faollashtirildi.\n"
        "Buyurtmalarni qabul qilishingiz mumkin!\n\n"
        "👇 **Quyidagi tugma orqali VIP guruhga qo'shiling:**"
    )

    try:
        await callback.bot.send_message(
            uid, 
            welcome, 
            parse_mode="Markdown", 
            reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons)
        )
    except:
        pass

    await callback.message.edit_caption(
        caption=callback.message.caption + "\n\n✅ **TASDIQLANDI**",
        reply_markup=None
    )
    await callback.answer("To'lov tasdiqlandi!")


@router.callback_query(F.data.startswith("pay_reject_"), IsAdmin())
async def pay_reject(callback: types.CallbackQuery):
    _, _, pid_str, uid_str = callback.data.split("_")
    pid = int(pid_str)
    uid = int(uid_str)

    await db.update_payment_status(pid, 'rejected')
    await db.update_driver_status(uid, 'rejected')

    try:
        await callback.bot.send_message(
            uid,
            "❌ **To'lovingiz rad etildi.**\n\n"
            "Iltimos, **chekni qaytadan yuboring** yoki admin bilan bog'laning.\n\n"
            "<b>Qayta ariza yuborish uchun:</b>\n"
            "1. /start ni bosing\n"
            "2. Haydovchi bo'limiga o'ting\n"
            "3. To'lov chekini qayta yuboring",
            parse_mode="HTML"
        )
    except Exception as e:
        logger.warning(f"Haydovchiga rad etildi xabari yuborib bo'lmadi: {e}")

    await callback.message.edit_caption(
        caption=callback.message.caption + "\n\n❌ **RAD ETILDI**",
        reply_markup=None
    )
    await callback.answer("To'lov rad etildi!")


# ==========================================
# 6. QORA RO'YXAT VA BLOKLASH
# ==========================================
@router.callback_query(F.data == "admin_blacklist", IsAdmin())
async def admin_blacklist_view(callback: types.CallbackQuery):
    bl = await db.get_blacklist()
    if not bl:
        await callback.message.edit_text(
            "🚫 **Qora ro'yxat hozirda bo'sh.**",
            reply_markup=admin_back_kb(),
            parse_mode="HTML"
        )
        return

    await callback.message.edit_text(
        f"🚫 **QORA RO'YXATDA:** ({len(bl)} ta)",
        reply_markup=None
    )

    for b in bl:
        u = await db.get_user_by_query(str(b['user_id']))
        name = u['full_name'] if u else "Noma'lum"
        txt = (
            f"👤 **{name}** (`{b['user_id']}`)\n"
            f"📅 Vaqt: {b['created_at']}\n"
            f"💬 Sabab: {b['reason']}"
        )
        kb = types.InlineKeyboardMarkup(inline_keyboard=[
            [types.InlineKeyboardButton(
                text="✅ Bloqdan chiqarish",
                callback_data=f"unblock_global_{b['user_id']}"
            )]
        ])
        await callback.message.answer(txt, reply_markup=kb, parse_mode="Markdown")

    await callback.message.answer(
        "☝️ Foydalanuvchini bloqdan chiqarishingiz mumkin.",
        reply_markup=admin_back_kb(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("block_global_"), IsAdmin())
async def block_global_cb(callback: types.CallbackQuery):
    tid = int(callback.data.split("_")[2])
    await db.add_to_blacklist(tid)
    await callback.answer(f"🚫 ID: {tid} qora ro'yxatga qo'shildi!", show_alert=True)
    await callback.message.edit_reply_markup(reply_markup=None)


@router.callback_query(F.data.startswith("unblock_global_"), IsAdmin())
async def unblock_global_cb(callback: types.CallbackQuery):
    tid = int(callback.data.split("_")[2])
    await db.remove_from_blacklist(tid)
    await callback.answer(f"✅ ID: {tid} qora ro'yxatdan olindi!", show_alert=True)
    await callback.message.edit_reply_markup(reply_markup=None)


# ==========================================
# 7. XABAR YUBORISH (BROADCAST)
# ==========================================
@router.callback_query(F.data == "admin_broadcast", IsAdmin())
async def admin_broadcast_start(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    await callback.message.edit_text(
        "📢 **XABAR YUBORISH (BROADCAST)**\n"
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
        "Barcha foydalanuvchilarga xabar yuborish uchun matnni kiriting (rasm yoki video ham mumkin):",
        reply_markup=admin_back_kb(),
        parse_mode="Markdown"
    )
    await state.set_state(AdminState.waiting_broadcast_msg)

@router.message(AdminState.waiting_broadcast_msg, IsAdmin())
async def admin_broadcast_msg(message: types.Message, state: FSMContext, bot: Bot):
    # Xabarni saqlab turamiz va tugma qo'shishni so'raymiz
    await state.update_data(msg_id=message.message_id, chat_id=message.chat.id)
    
    # Copy message to show preview
    try:
        await message.copy_to(chat_id=message.chat.id)
    except: pass

    await message.answer(
        "☝️ Xabar ko'rinishi yuqoridagidek bo'ladi.\n\n"
        "Agar tugma (havola) qo'shmoqchi bo'lsangiz, uni quyidagi formatda yuboring:\n"
        "`Tugma nomi - https://manzil.com`\n\n"
        "Yoki shunchaki **'tm'** (tugmasiz) deb yozing.",
        parse_mode="Markdown"
    )
    await state.set_state(AdminState.waiting_broadcast_button)

@router.message(AdminState.waiting_broadcast_button, IsAdmin())
async def admin_broadcast_send(message: types.Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    msg_id = data.get('msg_id')
    chat_id = data.get('chat_id')
    
    kb = None
    text = message.text.strip()
    
    if text.lower() != 'tm' and '-' in text:
        try:
            name, url = text.split('-', 1)
            kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=name.strip(), url=url.strip())]])
        except:
            await message.answer("⚠️ Format noto'g'ri! Qayta kiriting yoki 'tm' dbe yozing.")
            return

    # Broadcast
    users = await db.get_all_users_for_broadcast()
    count = 0
    blocked = 0
    
    status_msg = await message.answer(f"⏳ **Yuborilmoqda...** (Jami: {len(users)})", parse_mode="Markdown")
    
    for uid in users:
        try:
            await bot.copy_message(chat_id=uid, from_chat_id=chat_id, message_id=msg_id, reply_markup=kb)
            count += 1
        except Exception as e:
            blocked += 1
            await asyncio.sleep(0.05)
            
        if count % 20 == 0:
            await asyncio.sleep(0.5)
            
    await status_msg.edit_text(
        f"✅ **YUBORILDI**\n\n"
        f"✉️ Muvaffaqiyatli: {count}\n"
        f"🚫 Bloklaganlar (yoki xato): {blocked}",
        parse_mode="Markdown",
        reply_markup=admin_back_kb()
    )
    await state.clear()


# ==========================================
# 8. BAZA (DOWNLOAD DB)
# ==========================================
@router.callback_query(F.data == "admin_download_db", IsAdmin())
async def admin_download_db(callback: types.CallbackQuery):
    from aiogram.types import FSInputFile
    file = FSInputFile(DB_PATH, filename=f"database_{datetime.now().strftime('%Y%m%d')}.db")
    await callback.message.answer_document(file, caption="📁 **Asosiy ma'lumotlar bazasi**", parse_mode="Markdown")
    await callback.answer()


# ==========================================
# 9. GURUHLAR BOSHQARUVI
# ==========================================
@router.callback_query(F.data == "admin_groups", IsAdmin())
async def admin_groups_manage(callback: types.CallbackQuery):
    vip_g = await db.get_setting('vip_group_ids', str(VIP_GROUP_ID))
    driver_g = await db.get_setting('free_group_ids', str(DRIVER_GROUP_ID))
    
    text = (
        "👥 **GURUHLAR BOSHQARUVI**\n"
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"💎 **VIP Guruhlar:** `{vip_g}`\n"
        f"🚕 **Oddiy Guruhlar:** `{driver_g}`\n\n"
        "O'zgartirish uchun pastdagi tugmalarni bosing:"
    )
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ VIP guruhlarni o'zgartirish", callback_data="edit_vip_groups")],
        [InlineKeyboardButton(text="✏️ Oddiy guruhlarni o'zgartirish", callback_data="edit_free_groups")],
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data="admin_main_menu")]
    ])
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.in_(["edit_vip_groups", "edit_free_groups"]), IsAdmin())
async def admin_edit_groups(callback: types.CallbackQuery, state: FSMContext):
    g_type = "vip_group_ids" if callback.data == "edit_vip_groups" else "free_group_ids"
    await state.update_data(setting_key=g_type)
    
    await callback.message.edit_text(
        f"📝 **Yangi ID larni kiriting** ({g_type}):\n\n"
        "Vergul bilan ajratib yozing: `-100123,-100456`",
        reply_markup=admin_back_kb(),
        parse_mode="Markdown"
    )
    await state.set_state(AdminState.waiting_setting_value)

@router.message(AdminState.waiting_setting_value, IsAdmin())
async def admin_save_setting(message: types.Message, state: FSMContext):
    data = await state.get_data()
    key = data.get('setting_key')
    val = message.text.strip()
    
    await db.set_setting(key, val)
    await message.answer(f"✅ **Sozlama saqlandi:** `{val}`", parse_mode="Markdown", reply_markup=admin_back_kb())
    await state.clear()


# ==========================================
# 10. QO'SHIMCHA RO'YXATLAR (VIZUAL)
# ==========================================
# ==========================================
# 10. QO'SHIMCHA RO'YXATLAR VA FOYDALANUVCHILARNI BOSHQARISH
# ==========================================
@router.callback_query(F.data == "admin_users_menu", IsAdmin())
async def admin_users_menu_cb(callback: types.CallbackQuery):
    from bot.keyboards.inline import admin_users_kb
    await callback.message.edit_text(
        "👥 **FOYDALANUVCHILAR BOSHQARUVI**\n"
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
        "Qaysi ro'yxatni ko'rmoqchisiz?",
        reply_markup=admin_users_kb(),
        parse_mode="Markdown"
    )
    await callback.answer()

async def format_users_list(users, title):
    if not users:
        return f"📭 **{title} topilmadi.**"
    
    text = f"📋 **{title}** (Oxirgi 20 ta):\n\n"
    for u in users[:20]:
        reg_date = u.get('joined_at', 'Noma\'lum')
        if reg_date != 'Noma\'lum':
            try:
                reg_date = str(reg_date)[:16] # YYYY-MM-DD HH:MM
            except: pass
            
        role = u.get('role', 'driver' if 'car_type' in u else 'passenger')
        chat_link = f"tg://user?id={u['telegram_id']}"
        
        text += (
            f"👤 <a href='{chat_link}'>{u['full_name']}</a>\n"
            f"🛠 <b>Role:</b> {role.upper()}\n"
            f"📅 <b>Sana:</b> {reg_date}\n"
            f"🆔 <code>{u['telegram_id']}</code>\n"
            "➖➖➖➖➖➖➖➖\n"
        )
    return text

@router.callback_query(F.data.in_([
    "show_all_drivers", "show_all_passengers", 
    "show_vip_drivers", "show_all_users_combined"
]), IsAdmin())
async def show_users_generic(callback: types.CallbackQuery):
    action = callback.data
    users = []
    title = ""
    
    if action == "show_all_drivers":
        users = await db.get_all_drivers(limit=50) # Limit oshirildi
        title = "HAYDOVCHILAR"
    elif action == "show_all_passengers":
        users = await db.get_users_by_role('passenger')
        # Sort by latest if possible, but existing SQL might no support sort param in get_users_by_role
        # Let's assume it returns list and we sort Py-side or just show as is
        users.reverse() # Assume DB returns oldest first if no order
        title = "YO'LOVCHILAR"
    elif action == "show_vip_drivers":
        users = await db.get_users_by_role('driver', is_vip=True)
        title = "VIP HAYDOVCHILAR"
    elif action == "show_all_users_combined":
        users = await db.get_users_by_role('all')
        users.sort(key=lambda x: str(x.get('joined_at', '')), reverse=True)
        title = "BARCHA FOYDALANUVCHILAR"

    # Agar ro'yxat juda uzun bo'lsa, fayl taklif qilamiz
    if len(users) > 20: 
        # Fayl tayyorlash
        report = "Telegram ID, Full Name, Phone, Role, Joined At\n"
        for u in users:
            r = u.get('role', 'driver' if 'car_type' in u else 'passenger')
            j = u.get('joined_at', '')
            report += f"{u['telegram_id']}, {u.get('full_name','?')}, {u.get('phone','?')}, {r}, {j}\n"
        
        from aiogram.types import BufferedInputFile
        file = BufferedInputFile(report.encode('utf-8'), filename=f"{action}.csv")
        
        # Ekranga qisqacha chiqarish
        preview_text = await format_users_list(users, title)
        await callback.message.edit_text(preview_text, parse_mode="HTML", reply_markup=admin_back_kb())
        await callback.message.answer_document(file, caption="📂 To'liq ro'yxat (.csv)")
    else:
        text = await format_users_list(users, title)
        await callback.message.edit_text(text, parse_mode="HTML", reply_markup=admin_back_kb())
    
    await callback.answer()

@router.callback_query(F.data == "admin_search_user", IsAdmin())
async def admin_search_user_start(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.edit_text(
        "🔎 **FOYDALANUVCHI QIDIRISH**\n"
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
        "Qidirish uchun **Telegram ID** yoki **Telefon raqam** kiriting:",
        reply_markup=admin_back_kb(),
        parse_mode="Markdown"
    )
    await state.set_state(AdminState.waiting_user_search)

@router.message(AdminState.waiting_user_search, IsAdmin())
async def admin_search_user_result(message: types.Message, state: FSMContext):
    query = message.text.strip().replace("+", "")
    user = await db.get_user_by_query(query)
    
    if not user:
        await message.answer("❌ **Foydalanuvchi topilmadi.**", reply_markup=admin_back_kb(), parse_mode="Markdown")
        return

    # User details
    role = user.get('role', 'driver' if 'car_type' in user else 'passenger')
    j_at = user.get('joined_at', 'Noma\'lum')
    
    text = (
        f"🔎 **QIDIRUV NATIJASI:**\n"
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"👤 <b>Ism:</b> {user['full_name']}\n"
        f"🛠 <b>Role:</b> {role.upper()}\n"
        f"📞 <b>Tel:</b> +{user.get('phone', 'Yo\'q')}\n"
        f"🆔 <b>ID:</b> <code>{user['telegram_id']}</code>\n"
        f"📅 <b>Sana:</b> {j_at}\n"
    )
    
    if role == 'driver':
        text += (
            f"🚗 <b>Mashina:</b> {user.get('car_type', '-')}\n"
            f"💰 <b>Balans:</b> {user.get('balance', 0):,} so'm\n"
            f"⚙️ <b>Status:</b> {user.get('status', '-')}\n"
        )
        # Edit/Manage buttons specific to driver could be added here
        
    chat_link = f"tg://user?id={user['telegram_id']}"
    
    # Tugmalar
    keyboard = []
    
    if role == 'driver':
        s = user.get('status', 'unknown')
        if s != 'active':
            keyboard.append([InlineKeyboardButton(text="✅ Faollashtirish (Active)", callback_data=f"set_status_active_{user['telegram_id']}")])
        if s != 'rejected':
            keyboard.append([InlineKeyboardButton(text="❌ Rad etish (Reject)", callback_data=f"set_status_rejected_{user['telegram_id']}")])
        if s != 'pending':
            keyboard.append([InlineKeyboardButton(text="⏳ Kutilmoqda (Pending)", callback_data=f"set_status_pending_{user['telegram_id']}")])

    keyboard.append([InlineKeyboardButton(text="👤 Profilga o'tish", url=chat_link)])
    keyboard.append([InlineKeyboardButton(text="⬅️ Ortga", callback_data="admin_users_menu")])
    
    await message.answer(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(inline_keyboard=keyboard))
    await state.clear()


@router.callback_query(F.data.startswith("set_status_"), IsAdmin())
async def admin_set_status_manual(callback: types.CallbackQuery):
    parts = callback.data.split("_")
    # set_status_active_12345
    new_status = parts[2]
    uid = int(parts[3])
    
    await db.update_driver_status(uid, new_status)
    await callback.answer(f"Status {new_status} ga o'zgartirildi!", show_alert=True)
    
    # Xabarni yangilash uchun shunchaki xabar beramiz
    await callback.message.answer(f"✅ Haydovchi ({uid}) statusi **{new_status.upper()}** ga o'zgartirildi.")


# ==========================================
# 11. ADMINLARNI BOSHQARISH
# ==========================================
@router.callback_query(F.data == "admin_manage_admins", IsAdmin())
async def admin_manage_list(callback: types.CallbackQuery):
    current_admins = await db.get_setting('admin_ids', "")
    text = (
        f"🛡 **ADMINLAR RO'YXATI**\n\n"
        f"`{current_admins}`\n\n"
        "Yangi admin qo'shish uchun pastdagi tugmani bosing (Admin ID kerak)."
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Admin qo'shish", callback_data="add_new_admin")],
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data="admin_main_menu")]
    ])
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="Markdown") 

@router.callback_query(F.data == "add_new_admin", IsAdmin())
async def add_new_admin_start(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.answer("✍️ Yangi adminning **Telegram ID** raqamini yuboring:")
    await state.set_state(AdminState.waiting_new_admin_id)

@router.message(AdminState.waiting_new_admin_id, IsAdmin())
async def add_new_admin_save(message: types.Message, state: FSMContext):
    try:
        new_id = int(message.text.strip())
        from core.config import ADMIN_IDS
        # Config file o'zgarmaydi, lekin bazadagi settingni o'zgartirishimiz mumkin agar logikani shunga moslasak.
        # Hozircha configdagi ADMIN_IDS ni ishlatyapmiz, bu qiyin masala chunki reload kerak.
        # Lekin keling bazaga yozib qo'yamiz va keyingi safar tekshirganda bazadan ham o'qiydigan qilamiz.
        # Eslatma: IsAdmin filtri config.ADMIN_IDS ga qaraydi. Uni update qilish kerak dinamik bo'lishi uchun.
        # Hozircha shunchaki "O'zgartirildi" deb qo'yamiz, real update uchun `config.py` o'qishini o'zgartirish kerak.
        
        await message.answer("✅ Admin qo'shildi (Dinamik yangilash uchun bot qayta ishga tushishi kerak bo'lishi mumkin).")
    except:
        await message.answer("❌ ID raqam bo'lishi kerak.")
    await state.clear()


# ==========================================
# 12. SOZLAMALAR (SETTINGS)
# ==========================================
@router.callback_query(F.data == "admin_settings", IsAdmin())
async def admin_settings_menu(callback: types.CallbackQuery):
    # Asosiy narxlar va h.k.
    min_taxi = await db.get_setting('min_price_taxi', '20000')
    sub_fee = await db.get_setting('driver_subscription_fee', '20000')
    
    text = (
        "⚙️ **SOZLAMALAR**\n"
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"🚖 Min Taxi Narxi: `{min_taxi}`\n"
        f"💳 Obuna narxi: `{sub_fee}`\n"
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ Obuna narxini o'zgartirish", callback_data="edit_sub_fee")],
        [InlineKeyboardButton(text="⬅️ Ortga", callback_data="admin_main_menu")]
    ])
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="Markdown")

@router.callback_query(F.data == "edit_sub_fee", IsAdmin())
async def edit_sub_fee_flow(callback: types.CallbackQuery, state: FSMContext):
    await state.update_data(setting_key='driver_subscription_fee')
    await callback.message.answer("✍️ Yangi obuna narxini yozing (so'mda):")
    await state.set_state(AdminState.waiting_setting_value)


# ==========================================
# 13. GRABBER SOZLAMALARI (Stub)
# ==========================================
@router.callback_query(F.data == "admin_grabber", IsAdmin())
async def admin_grabber_menu(callback: types.CallbackQuery):
    await callback.answer("🛠 Tez orada ishga tushadi!", show_alert=True)
